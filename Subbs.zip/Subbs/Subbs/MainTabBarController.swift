//
//  MainTabBarController.swift
//  Subbs
//
//  Created by doyeonjeong on 4/16/24.
//

import UIKit

class MainTabBarController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.selectedIndex = 1
    }
}
