//
//  SubwayBookmarkCell.swift
//  Subbs
//
//  Created by doyeonjeong on 4/16/24.
//

import UIKit

class SubwayBookmarkCell: UITableViewCell {
    static let identifier = String(describing: SubwayBookmarkCell.self)

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
