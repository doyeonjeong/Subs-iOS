//
//  NearbySubwayCell.swift
//  Subbs
//
//  Created by doyeonjeong on 4/16/24.
//

import UIKit

class NearbySubwayCell: UITableViewCell {
    static let identifier = String(describing: NearbySubwayCell.self)

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
